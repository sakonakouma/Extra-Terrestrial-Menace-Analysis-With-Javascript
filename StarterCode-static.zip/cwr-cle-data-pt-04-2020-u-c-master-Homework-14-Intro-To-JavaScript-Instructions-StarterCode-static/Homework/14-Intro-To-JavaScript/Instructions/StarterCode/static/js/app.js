// from data.js
var tableData = data;

// YOUR CODE HERE!
